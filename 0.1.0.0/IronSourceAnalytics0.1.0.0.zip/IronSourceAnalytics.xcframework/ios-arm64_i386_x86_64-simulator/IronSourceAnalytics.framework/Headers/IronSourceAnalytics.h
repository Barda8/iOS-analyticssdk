//
//  IronSourceAnalytics.h
//  IronSourceAnalytics
//
//  Created by Bar David on 10/05/2021.
//

#import <Foundation/Foundation.h>

@class ISAnalyticsAnalyticsSdk;
@class ISAnalyticsMetaData;
@class ISAnalyticsConfigFile;
@class ISAnalyticsUserProgress;
@class ISAnalyticsResourceUpdate;
@class ISAnalyticsInAppPurchase;
@class ISAnalyticsUserActivity;

typedef NS_ENUM(NSInteger, ISAnalyticsPurchasingType);
typedef NS_ENUM(NSInteger, ISAnalyticsResourceType);
typedef NS_ENUM(NSInteger, ISAnalyticsResourceAction);
typedef NS_ENUM(NSInteger, ISAnalyticsProgressState);
typedef NS_ENUM(NSInteger, ISAnalyticsUserInfoGender);
typedef NS_ENUM(NSInteger, ISAnalyticsUserInfoLoginType);
typedef NS_ENUM(NSInteger, ISAnalyticsPrivacyRestriction);
typedef NS_ENUM(NSInteger, ISAnalyticsReason);
typedef NS_ENUM(NSInteger, ISAnalyticsMediationName);

//! Project version number for IronSourceAnalytics.
FOUNDATION_EXPORT double IronSourceAnalyticsVersionNumber;

//! Project version string for IronSourceAnalytics.
FOUNDATION_EXPORT const unsigned char IronSourceAnalyticsVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <IronSourceAnalytics/PublicHeader.h>

@interface IronSourceAnalytics : NSObject

+(void)initWithAppKey:(NSString *_Nonnull) appKey;

+(void)setIAPSettings:(ISAnalyticsPurchasingType) purchasingType withValues: (NSArray <NSString *>*) values;

+(void)setAppResourcesWithResourceType:(ISAnalyticsResourceType) resourceType withValues:(NSArray <NSString *>*) values;

+(void)setUserPrivacy:(ISAnalyticsPrivacyRestriction) toUpdate isRestricted:(BOOL) isRestricted withReason:(ISAnalyticsReason) why;

+(void)setUserId:(NSString *_Nonnull) userId;

+(void)setUserInfo:(NSArray <ISAnalyticsMetaData *>*) userInfo;

+(void)updateUserResources:(ISAnalyticsResourceUpdate *_Nonnull) appResource;

+(void)updateUserPurchase:(ISAnalyticsInAppPurchase *_Nonnull) appPurchase;

+(void)updateProgress:(ISAnalyticsUserProgress *_Nonnull) userProgress;

+(void)updateImpressionData:(ISAnalyticsMediationName) mediationName withImpressionData:(NSDictionary *_Nonnull) impressionData;

+(void)updateCustomActivity:(ISAnalyticsUserActivity * _Nonnull) appActivity;

+(NSString *_Nonnull)getSDKVersion;

@end
